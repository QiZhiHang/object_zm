<?php defined('ByFeiWa') or exit('Access Invalid!');?>
<?php echo $output['msg']; ?>