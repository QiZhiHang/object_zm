<?php defined('ByFeiWa') or exit('Access Invalid!');?>

<div>
    <div class="ncap-form-default">
      <dl class="row">
        <dt class="tit">
          <label for="attr_name">内容</label>
        </dt>
        <dd class="opt">
          <?php echo ubb($output['reply_info']['reply_content']);?>
        </dd>
      </dl>

    </div>
</div>
