<?php
defined('ByFeiWa') or exit('Access Invalid!');

$lang['snsalbum_album_setting']	= '相册设置';
$lang['snsalbum_allow_upload_max_count']	= '允许上传最大图片数量';
$lang['snsalbum_allow_upload_max_count_tip']= '0为不限制';
$lang['snsalbum_pls_input_figures']			= '请填写数字';
$lang['snsalbum_class_list']	= '相册列表';
$lang['snsalbum_class_name']	= '相册名称';
$lang['snsalbum_member_name']	= '会员名称';
$lang['snsalbum_add_time']		= '创建时间';
$lang['snsalbum_pic_count']		= '图片数量';
$lang['snsalbum_pic_list']		= '图片列表';
$lang['snsalbum_pic_name']		= '图片名称';
$lang['snsalbum_choose_need_del_img']		= '请选择要删除的图片';