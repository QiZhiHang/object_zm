<?php
defined('ByFeiWa') or exit('Access Invalid!');
/**
 * control
 */
$lang['circle_continue_add']	= '继续添加';
/**
 * setting
 */
$lang['circle_defaultlevel']	= '默认头衔';
$lang['circle_memberlevel']		= '成员头衔';
$lang['circle_memberlevelref']	= '头衔参考';
$lang['circle_memberleveladd']	= '添加参考';
$lang['circle_level']			= '级别';
$lang['circle_medal']			= '勋章';
$lang['circle_rank']			= '头衔';
$lang['circle_experience_required']	= '所需经验值';
$lang['circle_rank_not_null']	= '请填写内容';
$lang['circle_rank_maxlength']	= '不能超过4个字符';
$lang['circle_experience_error']= '请填写数字';
$lang['circle_memberlevelprompts']	= '修改默认头衔后请<a href="index.php?app=circle_memberlevel&feiwa=update_cache">更新圈子缓存</a>。';
/**
 * add
 */
$lang['circle_memberlevelgroup']= '头衔组名称';
$lang['circle_is_use']			= '是否开启';
$lang['circle_rankname']		= '头衔名称';
$lang['circle_memberlevelgroupname_not_null']	= '请填写头衔组名称';

/**
 * edit
 */
$lang['circle_memberleveledit']	= '编辑参考';

/**
 * ref
 */
$lang['circle_addtime']			= '添加时间';