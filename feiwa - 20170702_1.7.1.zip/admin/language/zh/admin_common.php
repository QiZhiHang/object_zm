<?php
defined('ByFeiWa') or exit('Access Invalid!');

//common.php 調用

$lang['feiwa_comm_workarea']	=  '工作區域';
$lang['feiwa_comm_cut_view']	=  '裁切預覽';
$lang['feiwa_comm_op_help']	=  '操作幫助';
$lang['feiwa_comm_op_help_tip']=  '請在工作區域放大縮小及移動選取框，選擇要裁剪的範圍，裁切寬高比例固定；裁切後的效果為右側預覽圖所顯示；保存提交後生效。';