<?php
defined('ByFeiWa') or exit('Access Invalid!');

$config['sys_log']          = true;

return $config;
