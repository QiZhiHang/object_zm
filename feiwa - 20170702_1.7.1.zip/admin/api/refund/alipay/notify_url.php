<?php
/**
 * 支付宝服务器异步通知页面
 *
 * 
 * @山东破浪网络科技有限公司提供技术支持 授权请购买FeiWa授权
 * @license    http://www.feiwa.org
 * @link       联系电话：0539-889333 客服QQ：2116198029
 */
$_GET['app']	= 'notify_refund';
$_GET['feiwa']		= 'alipay';
require_once(dirname(__FILE__).'/../../../index.php');
?>